from odoo import models, fields

class GrievanceCategory(models.Model):
    _name = 'discipline.grievance.category'
    _description = 'Grievance Category'

    name = fields.Char(required=True)
    description = fields.Text()