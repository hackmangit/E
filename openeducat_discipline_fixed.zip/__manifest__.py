{
    "name": "OpenEduCat Discipline",
    "version": "1.0",
    "category": "Education",
    "summary": "Manage student discipline cases, offences, and grievances",
    "depends": ["openeducat_core"],
    "data": [
        "security/ir.model.access.csv",
        "views/menu.xml",
        "views/discipline_view.xml",
        "views/offence_view.xml",
        "views/misbehaviour_view.xml",
        "views/grievance_view.xml",
        "views/grievance_category_view.xml"
    ],
    "installable": True,
    "application": True
}