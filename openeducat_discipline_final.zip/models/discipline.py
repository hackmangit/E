from odoo import models, fields, api

class DisciplineCase(models.Model):
    _name = 'discipline.case'
    _description = 'Discipline Case'

    name = fields.Char(required=True)
    student_id = fields.Many2one('op.student', string='Student', required=True)
    date_reported = fields.Date(default=fields.Date.today)
    offence_id = fields.Many2one('discipline.offence', string="Offence")
    misbehaviour_type_id = fields.Many2one('discipline.misbehaviour', string='Misbehaviour Type')
    description = fields.Text()
    action_taken = fields.Text()
    state = fields.Selection([
        ('draft', 'Draft'),
        ('under_review', 'Under Review'),
        ('closed', 'Closed')
    ], default='draft')