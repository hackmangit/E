from odoo import models, fields

class Grievance(models.Model):
    _name = 'discipline.grievance'
    _description = 'Student Grievance'

    name = fields.Char(required=True)
    student_id = fields.Many2one('op.student', string='Student', required=True)
    category_id = fields.Many2one('discipline.grievance.category', string='Category')
    date_filed = fields.Date(default=fields.Date.today)
    description = fields.Text()
    resolution = fields.Text()
    status = fields.Selection([
        ('draft', 'Draft'),
        ('in_progress', 'In Progress'),
        ('resolved', 'Resolved')
    ], default='draft')