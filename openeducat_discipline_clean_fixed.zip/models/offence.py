from odoo import models, fields

class DisciplineOffence(models.Model):
    _name = 'discipline.offence'
    _description = 'School Offence'

    name = fields.Char(required=True)
    code = fields.Char(help="Unique code for this offence")
    description = fields.Text()