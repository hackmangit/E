{
    "name": "OpenEduCat Discipline",
    "version": "18.0.1.0.0",
    "summary": "Manage student discipline, rules, and actions",
    "author": "Tarcin Robotics",
    "license": "OPL-1",
    "website": "https://tarcinrobotic.in",
    "depends": ["openeducat_core", "mail"],
    "data": [
        "security/discipline_security.xml",
        "security/ir.model.access.csv",
        "views/discipline_views.xml",
        "data/discipline_sequence.xml"
    ],
    "application": True,
    "installable": True
}
