{
    "name": "OpenEduCat Discipline",
    "version": "1.0",
    "category": "Education",
    "summary": "Manage student discipline records",
    "depends": ["base"],
    "data": [
        "data/model.xml",
        "security/ir.model.access.csv",
        "views/discipline_view.xml",
        "views/menu.xml"
    ],
    "installable": True,
    "application": True
}