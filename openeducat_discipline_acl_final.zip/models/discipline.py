from odoo import models, fields, api

class Discipline(models.Model):
    _name = 'op.discipline'
    _description = 'Discipline Record'

    name = fields.Char(default="New", readonly=True)
    active = fields.Boolean(default=True)
    student_id = fields.Many2one('res.partner', string='Student')
    date = fields.Date(default=fields.Date.today)
    discipline_master = fields.Many2one('res.users', string='Discipline Master')
    recipients_ids = fields.Many2many('res.partner', string='Recipients')
    progression_id = fields.Many2one('res.partner', string='Progression No')
    course_id = fields.Many2one('res.partner', string='Course')
    priority = fields.Selection([
        ('0', 'Normal'),
        ('1', 'Low'),
        ('2', 'High'),
        ('3', 'Very High')
    ], string='Priority')
    company_id = fields.Many2one('res.company', string='Company')
    misbehaviour_type = fields.Selection([
        ('academic', 'Academic'),
        ('behavioral', 'Behavioral')
    ], string='Misbehaviour Type')
    misbehaviour_category_id = fields.Many2one('res.partner', string='Misbehaviour Category')
    misbehaviour_action = fields.Char(string='Action To Be Taken')
    merit_points = fields.Float()
    demerit_points = fields.Float()
    meeting_datetime = fields.Datetime()
    note = fields.Text()
    state = fields.Selection([
        ('draft', 'Draft'),
        ('email_sent', 'Email Sent'),
        ('awaiting_letter', 'Awaiting Letter'),
        ('awaiting_meeting', 'Awaiting Meeting'),
        ('action_taken', 'Action Taken')
    ], default='draft', tracking=True)

    def send_email(self):
        for record in self:
            record.state = 'email_sent'

    def apologies_letter(self):
        for record in self:
            record.state = 'awaiting_letter'

    def meeting_awaiting(self):
        for record in self:
            record.state = 'awaiting_meeting'

    def reset_draft(self):
        for record in self:
            record.state = 'draft'