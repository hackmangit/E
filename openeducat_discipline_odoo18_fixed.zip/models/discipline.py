from odoo import models, fields, api, _

class OpDiscipline(models.Model):
    _name = 'x_x_op_discipline'
    _description = 'Discipline Record'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Record Number", required=True, default="New", copy=False)
    student_id = fields.Many2one("op.student", string="Student", required=True, tracking=True)
    rule_violated = fields.Char(string="Rule Violated", required=True)
    reported_by = fields.Many2one("res.users", string="Reported By", default=lambda self: self.env.user)
    description = fields.Text(string="Details")
    date_reported = fields.Date(default=fields.Date.today)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('review', 'Under Review'),
        ('action_taken', 'Action Taken'),
        ('closed', 'Closed')
    ], default='draft', tracking=True)

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('x_x_op_discipline') or 'New'
        return super(OpDiscipline, self).create(vals)
