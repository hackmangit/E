{
    "name": "OpenEduCat Certification Enterprise",
    "version": "16.0.1.0.0",
    "summary": "Digital Certificate Issuance and Workflow for OpenEduCat",
    "author": "Tarcin Robotics",
    "license": "OPL-1",
    "website": "https://tarcinrobotic.in",
    "depends": ["openeducat_core", "mail"],
    "data": [
        "security/certification_security.xml",
        "security/ir.model.access.csv",
        "data/certificate_sequence.xml",
        "views/certification_views.xml"
    ],
    "application": True,
    "installable": True
}
