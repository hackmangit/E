# OpenEduCat Certification Enterprise

### Description

This module provides an advanced certification workflow for OpenEduCat institutions. Issue and manage course completion or merit certificates with approval stages, QR-token verification, and secure issuance tracking.

### Key Features

- Certificate types: Completion, Merit, Custom
- Role-based issuance workflow (Draft → Approved → Issued)
- QR token generation for digital verification
- Integrated with Students and Courses

### Dependencies

- openeducat_core
- mail

### Installation

1. Place this folder in your Odoo addons directory.
2. Update App List from Apps.
3. Install "OpenEduCat Certification Enterprise" module.

### License

OPL-1
