from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
import uuid

class OpCertificate(models.Model):
    _name = "op.certificate"
    _description = "Student Certificate"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = "issue_date desc"

    name = fields.Char("Certificate ID", required=True, copy=False, readonly=True, default=lambda self: _('New'))
    student_id = fields.Many2one("op.student", string="Student", required=True, tracking=True)
    course_id = fields.Many2one("op.course", string="Course", required=True, tracking=True)
    issue_date = fields.Date("Issue Date", default=fields.Date.today, tracking=True)
    certificate_type = fields.Selection([
        ("completion", "Course Completion"),
        ("merit", "Merit Certificate"),
        ("custom", "Custom Certificate"),
    ], default="completion", required=True, tracking=True)
    description = fields.Text("Remarks / Achievements")
    qr_token = fields.Char("QR Token", readonly=True, copy=False)
    state = fields.Selection([
        ("draft", "Draft"),
        ("approved", "Approved"),
        ("issued", "Issued"),
        ("cancelled", "Cancelled"),
    ], default="draft", tracking=True, string="Status")

    @api.model
    def create(self, vals):
        if vals.get("name", "New") == "New":
            vals["name"] = self.env["ir.sequence"].next_by_code("op.certificate") or _("New")
        vals["qr_token"] = str(uuid.uuid4())
        return super(OpCertificate, self).create(vals)

    def action_approve(self):
        for rec in self:
            if rec.state != 'draft':
                raise ValidationError(_("Only draft certificates can be approved."))
            rec.state = 'approved'

    def action_issue(self):
        for rec in self:
            if rec.state != 'approved':
                raise ValidationError(_("Only approved certificates can be issued."))
            rec.state = 'issued'

    def action_cancel(self):
        self.state = 'cancelled'
