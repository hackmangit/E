{
    "name": "OpenEduCat Discipline",
    "version": "1.0",
    "summary": "Student discipline record management",
    "category": "Education",
    "depends": ["base"],
    "data": [
        "security/ir.model.access.csv",
        "views/discipline_views.xml"
    ],
    "installable": True,
    "application": True
}
