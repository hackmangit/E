from odoo import models, fields

class Discipline(models.Model):
    _name = "op.discipline"
    _description = "Discipline Record"

    name = fields.Char("Name", required=True)
    student_id = fields.Many2one("res.partner", string="Student")
    course_id = fields.Many2one("res.partner", string="Course")
    date = fields.Date(string="Date")
    state = fields.Selection([
        ('draft', 'Draft'),
        ('sent', 'Email Sent'),
        ('meeting', 'Meeting Scheduled'),
        ('closed', 'Closed')
    ], default='draft', string="Status")
    description = fields.Text("Description")