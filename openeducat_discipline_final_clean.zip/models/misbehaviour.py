from odoo import models, fields

class MisbehaviourCategory(models.Model):
    _name = 'discipline.misbehaviour'
    _description = 'Misbehaviour Category'

    name = fields.Char(required=True)
    description = fields.Text()